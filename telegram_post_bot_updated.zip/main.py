import os
import requests
import time
from telegram import Bot, InputMediaPhoto
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")

bot = Bot(token=BOT_TOKEN)

def read_posts(filename):
    posts = []
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) < 13:
                continue
            item_id, image_url, _, title, original_price, sale_price, discount, _, _, _, _, orders, rating, link = parts
            post_text = generate_post_text(title, original_price, sale_price, discount, orders, rating, link, item_id)
            posts.append({
                "text": post_text,
                "image_url": image_url
            })
    return posts

def generate_post_text(title, original_price, sale_price, discount, orders, rating, link, item_id):
    try:
        original_price = float(original_price.replace("ILS", "").strip())
        sale_price = float(sale_price.replace("ILS", "").strip())
        discount_percent = round((1 - sale_price / original_price) * 100)
    except:
        discount_percent = discount.strip('%')

    rating_percent = f"{float(rating.strip('%')):.1f}%"
    orders_text = f"{orders} הזמנות" if int(orders) >= 50 else "פריט חדש לחברי הערוץ"

    return f"""🔥 אל תפספסו! מבצע חם 🛒

📦 {title.strip()}

⭐️ דירוג: {rating_percent}
📊 {orders_text}
💰 מחיר מבצע: {sale_price} ₪ ({discount_percent}% הנחה)
🚚 משלוח חינם או בעלות נמוכה
🔗 להזמנה: {link}

מספר פריט: {item_id}
להצטרפות לערוץ לחצו עליי👉 https://t.me/+LCv-Xuy6z9RjY2I0"""

def download_image(url, filename):
    response = requests.get(url)
    if response.status_code == 200:
        with open(filename, 'wb') as f:
            f.write(response.content)
        return filename
    return None

def main():
    posts = read_posts("posts.txt")
    for post in posts:
        image_path = download_image(post["image_url"], "temp.jpg")
        if image_path:
            try:
                bot.send_photo(chat_id=CHANNEL_ID, photo=open(image_path, 'rb'), caption=post["text"])
                print("Post sent!")
            except Exception as e:
                print(f"Error sending post: {e}")
            time.sleep(20)

if __name__ == "__main__":
    main()